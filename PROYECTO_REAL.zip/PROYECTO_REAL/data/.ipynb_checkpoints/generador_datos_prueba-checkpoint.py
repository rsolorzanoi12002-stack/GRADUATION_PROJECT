import json
import random
from datetime import datetime, timedelta
import os

class GeneradorDatosPruebaDiciembre2025:
    def __init__(self):
        self.ubicaciones = [
            "Campus Centenario - UPS Guayaquil",
            "Edificio de Ingeniería - Piso 3",
            "Biblioteca Central",
            "Laboratorio de Ciencias",
            "Cafetería Principal",
            "Área Deportiva",
            "Estacionamiento Norte",
            "Auditorio Central"
        ]
        
        self.dispositivos = [
            "UPS-SENSOR-001",
            "UPS-SENSOR-002", 
            "UPS-SENSOR-003",
            "UPS-SENSOR-004",
            "UPS-SENSOR-005"
        ]
        
        # Rangos realistas para CO2 (ppm) - Basados en estándares internacionales
        self.rangos_co2 = {
            "excelente": (350, 450),      # Excelente calidad - Exterior fresco
            "buena": (451, 600),          # Buena calidad - Bien ventilado
            "moderada": (601, 800),       # Moderada calidad - Ocupación normal
            "deficiente": (801, 1000),    # Deficiente calidad - Necesita ventilación
            "muy_deficiente": (1001, 1200), # Muy deficiente - Malestar posible
            "peligrosa": (1201, 2000)     # Peligrosa - Riesgo salud
        }
        
        # Patrón diario más realista para Guayaquil en diciembre
        self.patron_horario_co2 = {
            "madrugada": (0.7, 0.9),      # 00:00 - 06:00 (más bajo)
            "mañana": (0.9, 1.2),         # 06:00 - 10:00 (aumentando)
            "pico_mañana": (1.3, 1.6),    # 10:00 - 14:00 (más alto - clases)
            "tarde": (1.1, 1.4),          # 14:00 - 18:00 (descendiendo)
            "noche": (0.8, 1.1),          # 18:00 - 00:00 (bajando)
        }
        
        # Patrón semanal más realista (considerando actividad académica)
        self.patron_semanal_co2 = {
            0: 1.3,  # Lunes - actividad alta (inicio semana)
            1: 1.2,  # Martes - actividad alta
            2: 1.2,  # Miércoles - actividad alta
            3: 1.3,  # Jueves - actividad alta (preparación fin semana)
            4: 1.1,  # Viernes - actividad media (cierre temprano)
            5: 0.7,  # Sábado - actividad baja
            6: 0.6   # Domingo - actividad mínima
        }
        
        # Factores por tipo de ubicación (para hacerlas diferentes)
        self.factores_ubicacion = {
            "Campus Centenario - UPS Guayaquil": 0.9,   # Exterior - mejor aire
            "Edificio de Ingeniería - Piso 3": 1.3,     # Interior ocupado
            "Biblioteca Central": 1.2,                  # Interior con gente
            "Laboratorio de Ciencias": 1.4,             # Equipos + gente
            "Cafetería Principal": 1.5,                 # Mucha gente + cocina
            "Área Deportiva": 0.8,                      # Exterior ventilado
            "Estacionamiento Norte": 1.1,               # Gases vehículos
            "Auditorio Central": 1.0                    # Ocupación variable
        }
        
        # Historial para simular inercia (datos no cambian bruscamente)
        self.historial = {}
        
    def determinar_calidad_segun_fecha(self, fecha):
        """Determina calidad basada en fecha y día de la semana - más realista"""
        dia_semana = fecha.weekday()
        dia_mes = fecha.day
        hora = fecha.hour
        
        # Base por día de semana y hora
        if dia_semana < 5:  # Lunes a Viernes
            if 8 <= hora <= 16:  # Horas pico académicas
                calidades = ["excelente", "buena", "moderada", "deficiente", "muy_deficiente", "peligrosa"]
                pesos = [0.05, 0.20, 0.35, 0.25, 0.10, 0.05]
            elif 17 <= hora <= 21:  # Tarde/noche
                calidades = ["excelente", "buena", "moderada", "deficiente", "muy_deficiente", "peligrosa"]
                pesos = [0.10, 0.25, 0.30, 0.20, 0.10, 0.05]
            else:  # Madrugada
                calidades = ["excelente", "buena", "moderada", "deficiente", "muy_deficiente", "peligrosa"]
                pesos = [0.30, 0.40, 0.20, 0.07, 0.02, 0.01]
        else:  # Fin de semana
            if 10 <= hora <= 18:  # Día de fin de semana
                calidades = ["excelente", "buena", "moderada", "deficiente", "muy_deficiente", "peligrosa"]
                pesos = [0.20, 0.35, 0.25, 0.12, 0.05, 0.03]
            else:  # Noche/madrugada fin de semana
                calidades = ["excelente", "buena", "moderada", "deficiente", "muy_deficiente", "peligrosa"]
                pesos = [0.40, 0.35, 0.15, 0.07, 0.02, 0.01]
        
        # Efecto de días festivos (menos actividad)
        dias_festivos = [6, 7, 8, 24, 25, 31]  # Incluyendo días alrededor de festivos
        if dia_mes in dias_festivos:
            # Mejor calidad en festivos
            pesos = [0.35, 0.35, 0.20, 0.07, 0.02, 0.01]
        
        # Efecto de fin de semestre (después del 15 menos actividad)
        if dia_mes > 15:
            pesos = [peso * 1.2 for peso in pesos[:2]] + pesos[2:]  # Aumentar probabilidad buena calidad
            # Normalizar
            total = sum(pesos)
            pesos = [p/total for p in pesos]
        
        calidad = random.choices(calidades, pesos)[0]
        return calidad
    
    def obtener_franja_horaria(self, hora):
        """Determina franja horaria más precisa"""
        if 0 <= hora < 6:
            return "madrugada"
        elif 6 <= hora < 10:
            return "mañana"
        elif 10 <= hora < 14:
            return "pico_mañana"
        elif 14 <= hora < 18:
            return "tarde"
        else:
            return "noche"
    
    def generar_json_diciembre_2025(self, fecha_hora, ubicacion=None, dispositivo=None):
        """Genera un JSON para una fecha específica de diciembre 2025 - más realista"""
        
        # Determinar calidad según fecha
        calidad = self.determinar_calidad_segun_fecha(fecha_hora)
        co2_min, co2_max = self.rangos_co2[calidad]
        
        # Aplicar patrones horarios y semanales
        hora = fecha_hora.hour
        dia_semana = fecha_hora.weekday()
        dia_mes = fecha_hora.day
        
        # Determinar franja horaria
        franja = self.obtener_franja_horaria(hora)
        
        # Factor de ajuste por franja horaria
        factor_horario_min, factor_horario_max = self.patron_horario_co2[franja]
        factor_horario = random.uniform(factor_horario_min, factor_horario_max)
        
        # Factor de ajuste por día de la semana
        factor_semanal = self.patron_semanal_co2[dia_semana]
        
        # Ubicación y dispositivo
        ubicacion = ubicacion or random.choice(self.ubicaciones)
        dispositivo = dispositivo or random.choice(self.dispositivos)
        
        # Factor por ubicación
        factor_ubicacion = self.factores_ubicacion.get(ubicacion, 1.0)
        
        # Generar CO2 con todos los patrones
        co2_base = random.uniform(co2_min, co2_max)
        co2_ajustado = co2_base * factor_horario * factor_semanal * factor_ubicacion
        
        # Aplicar inercia (no cambios bruscos)
        key = f"{ubicacion}_{dispositivo}"
        if key in self.historial:
            co2_anterior = self.historial[key]
            # Máximo cambio del 20% por hora
            cambio_max = co2_anterior * 0.2
            co2_ajustado = co2_anterior + max(-cambio_max, min(cambio_max, co2_ajustado - co2_anterior))
        
        self.historial[key] = co2_ajustado
        
        # Temperatura más realista para Guayaquil en diciembre
        # Base: más caliente al mediodía, más fresco de noche
        temp_base = 25.0 + 5.0 * math.sin((hora - 14) * math.pi / 12)  # Pico a las 14:00
        
        # Ajuste por CO2 (lugares con más CO2 suelen ser más calientes)
        temp_ajuste_co2 = (co2_ajustado - 400) / 1000 * 2.0
        
        # Variación diaria aleatoria (clima cambia)
        temp_variacion_dia = random.uniform(-1.5, 1.5)
        
        # Efecto ubicación interior/exterior
        if "Campus" in ubicacion or "Área" in ubicacion or "Estacionamiento" in ubicacion:
            temp_exterior_factor = 1.0  # Exterior
        else:
            temp_exterior_factor = 1.1  # Interior suele ser más caliente
        
        temperatura = (temp_base + temp_ajuste_co2 + temp_variacion_dia) * temp_exterior_factor
        
        # Humedad más realista para Guayaquil (ciudad costera)
        # Más húmedo en la mañana y noche, menos al mediodía
        humedad_base = 75.0  # Guayaquil es húmedo
        humedad_variacion = 15.0 * math.sin((hora - 4) * math.pi / 12)  # Más alto a las 4 AM
        
        # Humedad más alta cuando hace calor (correlación real)
        humedad_calor_ajuste = -0.5 * (temperatura - 27.0)
        
        # Efecto de ubicación (interiores pueden ser más húmedos)
        if "Laboratorio" in ubicacion or "Cafetería" in ubicacion:
            humedad_ubicacion = random.uniform(5.0, 10.0)
        else:
            humedad_ubicacion = random.uniform(-5.0, 5.0)
        
        humedad = humedad_base + humedad_variacion + humedad_calor_ajuste + humedad_ubicacion
        humedad = max(40.0, min(95.0, humedad))  # Límites realistas
        
        # Presión atmosférica realista con tendencias
        presion_base = 1013.25
        # Variación diurna normal
        presion_diurna = 0.5 * math.sin(hora * math.pi / 12)
        # Tendencia a lo largo del mes (simulando sistemas meteorológicos)
        presion_mensual = 2.0 * math.sin(dia_mes * 2 * math.pi / 31)
        
        presion = presion_base + presion_diurna + presion_mensual + random.uniform(-1.0, 1.0)
        
        # MQ135 más realista (no solo correlacionado con CO2)
        mq135_base = (co2_ajustado - 400) * 0.15
        
        # Añadir picos aleatorios (otros contaminantes)
        if random.random() < 0.15:  # 15% de probabilidad de pico
            pico = random.uniform(10.0, 40.0)
            mq135_base += pico
        
        # Ruido del sensor
        ruido_sensor = random.normalvariate(0.0, 2.0)
        
        mq135_analog = max(0, mq135_base + ruido_sensor)
        mq135_digital = 1 if co2_ajustado > 1000 or mq135_analog > 100 else 0
        
        # Nivel de batería más realista
        dia_del_mes = fecha_hora.day
        # Base que disminuye gradualmente
        bateria_base = 98 - (dia_del_mes * 0.3)
        
        # La batería se descarga más rápido durante el día (más mediciones)
        if 8 <= hora <= 20:
            bateria_base -= random.uniform(0.1, 0.3)
        
        # Recargas aleatorias (simulando mantenimiento)
        if random.random() < 0.05:  # 5% de probabilidad de recarga
            bateria_base += random.uniform(10.0, 30.0)
        
        bateria = max(25, min(100, int(bateria_base + random.uniform(-3.0, 3.0))))
        
        # Coordenadas por ubicación
        coordenadas = {
            "Campus Centenario - UPS Guayaquil": (-2.170998, -79.922356),
            "Edificio de Ingeniería - Piso 3": (-2.171200, -79.922100),
            "Biblioteca Central": (-2.170800, -79.922500),
            "Laboratorio de Ciencias": (-2.171000, -79.921800),
            "Cafetería Principal": (-2.170500, -79.922300),
            "Área Deportiva": (-2.172000, -79.922000),
            "Estacionamiento Norte": (-2.171500, -79.921500),
            "Auditorio Central": (-2.170300, -79.922700)
        }
        
        lat, lon = coordenadas.get(ubicacion, (-2.170998, -79.922356))
        
        # Construir JSON
        datos = {
            "sensor_data": {
                "metadata": {
                    "device_id": dispositivo,
                    "location": ubicacion,
                    "timestamp": fecha_hora.isoformat(),
                    "latitude": lat,
                    "longitude": lon
                },
                "readings": {
                    "scd30": {
                        "co2": round(co2_ajustado, 2),
                        "temperature": round(temperatura, 2),
                        "humidity": round(humedad, 2)
                    },
                    "bme280": {
                        "temperature": round(temperatura + random.uniform(-0.3, 0.3), 2),
                        "humidity": round(humedad + random.uniform(-1.5, 1.5), 2),
                        "pressure": round(presion, 2)
                    },
                    "mq135": {
                        "analog_value": round(mq135_analog, 2),
                        "digital_value": mq135_digital
                    }
                },
                "system_info": {
                    "battery_level": bateria,
                    "sampling_interval": 3600
                }
            }
        }
        
        return datos, calidad

    # IMPORTANTE: Agregar este import al inicio de la clase
    import math

# El resto de tu código se mantiene IGUAL (generar_datos_diciembre_2025, 
# guardar_json, generar_y_guardar_diciembre_2025, y main)